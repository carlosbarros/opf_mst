#ifndef _DIPAPPDOCSIGN_H_
#define _DIPAPPDOCSIGN_H_


#ifdef __cplusplus
extern "C" {
#endif
    
#include <stdlib.h>
#include <stdlib.h>
    
    //int soma(int a,int b);
    void CheckInputData(float TrPercentage, float EvalPercentage, float TestPercentage);
    
    int splitDatabase(int argc, char **argv);
    
    int trainDatabase(int argc, char **argv);
    
    int classifyDatabase(int argc, char **argv);
    
    int accuracyDatabase(int argc, char **argv);
    
    int opfLearnopf_learn(int argc, char **argv);
    
    int opf_distance(int argc, char **argv);
    
    int opf_cluster(int argc, char **argv);
    
    int opf_knn_classify(int argc, char **argv);
    
    int opf2txt(int argc, char **argv);
    
    int txt2opf(int argc, char **argv);
    
    int statistics(int argc, char **argv);
    
    int opfmedidamodificadas(int argc, char **argv);
    
    int somadoisnumero(int a,int b);
    
    
#ifdef __cplusplus
}
#endif

#endif //_DIPAPPDOCSIGN_H_
