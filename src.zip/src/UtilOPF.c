#include "UtilOPF.h"
#include <stdlib.h>
#include <string.h>
#include "OPF.h"
#include <stdio.h>
#include <math.h>

#define WIN32_LEAN_AND_MEAN
#include <sys/timeb.h>
#include <sys/types.h>
#include <stdint.h>

#define _CRT_SECURE_NO_WARNINGS
// MSVC defines this in winsock2.h!?

FILE *fileNameResults;
int dist; //testar com quantas distancias
int nlabelss;
int run,lt=1;
float medidas[10][9]; //TIME TEST | TIME TRAIN | ACC | RECALL | F-SCORE
char distance[33];

float **confMatrixPercentual;

/*int gettimeofday(struct timeval * tp, struct timezone * tzp)
{
    // Note: some broken versions only have 8 trailing zero's, the correct epoch has 9 trailing zero's
    static const uint64_t EPOCH = ((uint64_t) 116444736000000000ULL);

    SYSTEMTIME  system_time;
    FILETIME    file_time;
    uint64_t    time;

    GetSystemTime( &system_time );
    SystemTimeToFileTime( &system_time, &file_time );
    time =  ((uint64_t)file_time.dwLowDateTime )      ;
    time += ((uint64_t)file_time.dwHighDateTime) << 32;

    tp->tv_sec  = (long) ((time - EPOCH) / 10000000L);
    tp->tv_usec = (long) (system_time.wMilliseconds * 1000);
    return 0;
}
#endif*/

//1� passo  - split do database (../bin/opf_split  ../data/boat.dat 0.5 0 0.5 0)
void CheckInputData(float TrPercentage, float EvalPercentage, float TestPercentage){
	fprintf(stderr, "\nSummation of set percentages = %.1f ...",TrPercentage+EvalPercentage+TestPercentage);
	if((float)(TrPercentage+EvalPercentage+TestPercentage) != (float)1.0)
		Error("Percentage summation is not equal to 1","CheckInputData");
	fprintf(stderr, " OK");

	fprintf(stderr, "\nChecking set percentages ...");
	if(TrPercentage == 0.0f || TestPercentage == 0.0f)
		Error("Percentage of either training set or test set is equal to 0", "CheckInputData");
	printf(" OK");
}
int splitDatabase(int argc, char **argv){

	Subgraph *g = NULL, *gAux = NULL, *gTraining = NULL, *gEvaluating = NULL, *gTesting = NULL;
	float training_p = atof(argv[2]), evaluating_p = atof(argv[3]), testing_p = atof(argv[4]);
	int normalize = atoi(argv[5]);

	fflush(stdout);
	fprintf(stdout, "\nProgram that generates training, evaluation and test sets for the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if(argc != 6){
		fprintf(stderr, "\nusage opf_split <P1> <P2> <P3> <P4> <P5>");
		fprintf(stderr, "\nP1: input dataset in the OPF file format");
		fprintf(stderr, "\nP2: percentage for the training set size [0,1]");
		fprintf(stderr, "\nP3: percentage for the evaluation set size [0,1] (leave 0 in the case of no learning)");
		fprintf(stderr, "\nP4: percentage for the test set size [0,1]");
		fprintf(stderr, "\nP5: normalize features? 1 - Yes  0 - No\n\n");
		exit(-1);
	}
    setDistanceOPFPedrosa(1);
	
	CheckInputData(training_p, evaluating_p, testing_p);

	fprintf(stdout, "\nReading data set ..."); fflush(stdout);
	g = ReadSubgraph(argv[1]);
	fprintf(stdout, " OK"); fflush(stdout);

	if(normalize) opf_NormalizeFeatures(g);

	fprintf(stdout, "\nSplitting data set ..."); fflush(stdout);
	opf_SplitSubgraph(g, &gAux, &gTesting, training_p+evaluating_p);

	if (evaluating_p > 0)
	  opf_SplitSubgraph(gAux, &gTraining, &gEvaluating, training_p/(training_p+evaluating_p));
	else gTraining = CopySubgraph(gAux);

	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting data sets to disk ..."); fflush(stdout);
	WriteSubgraph(gTraining, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/training.dat");
	if (evaluating_p > 0) WriteSubgraph(gEvaluating, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/evaluating.dat");
	WriteSubgraph(gTesting, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/testing.dat");
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ...");
	DestroySubgraph(&g);
	DestroySubgraph(&gAux);
	DestroySubgraph(&gTraining);
	DestroySubgraph(&gEvaluating);
	DestroySubgraph(&gTesting);
	fprintf(stdout, " OK\n");

	return 0;
}
//2� passo - train (training.dat)
int trainDatabase(int argc, char **argv){

	int n, i;
	char fileName[256];
	FILE *f = NULL;
	Subgraph *g = NULL;
	struct timeval tic, toc;
	float time;
	
	fflush(stdout);
	fprintf(stdout, "\nProgram that executes the training phase of the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if((argc != 3) && (argc != 2)){
		fprintf(stderr, "\nusage opf_train <P1> <P2>");
		fprintf(stderr, "\nP1: training set in the OPF file format");
		fprintf(stderr, "\nP2: precomputed distance file (leave it in blank if you are not using this resource)\n");
		exit(-1);
	}
    
     setDistanceOPFPedrosa(1);


	if(argc == 3) opf_PrecomputedDistance = 1;

	fprintf(stdout, "\nReading data file ..."); fflush(stdout);
	g = ReadSubgraph(argv[1]);
	fprintf(stdout, " OK"); fflush(stdout);

	if(opf_PrecomputedDistance)
		opf_DistanceValue = opf_ReadDistances(argv[2], &n);

	fprintf(stdout, "\nTraining OPF classifier ..."); fflush(stdout);
	
	gettimeofday(&tic,NULL); 
	opf_OPFTraining(g); 
	gettimeofday(&toc,NULL);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting classifier's model file ..."); fflush(stdout);
	opf_WriteModelFile(g, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/classifier.opf");
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"w");
	for (i = 0; i < g->nnodes; i++)
		fprintf(f,"%d\n",g->node[i].label);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ..."); fflush(stdout);
	DestroySubgraph(&g);
	if(opf_PrecomputedDistance){
		for (i = 0; i < n; i++)
			free(opf_DistanceValue[i]);
		free(opf_DistanceValue);
	}
	fprintf(stdout, " OK\n");

	time = ((toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001)/1000.0;
	fprintf(stdout, "\nTraining time: %f seconds\n", time); fflush(stdout);

	sprintf(fileName,"%s.time",argv[1]);
	f = fopen(fileName,"a");
	fprintf(f,"%f\n",time);
	//fprintf(fileNameResults,"%s %f \n","#Time Train		:",time);
	medidas[dist-1][1] = time;//time train
	fclose(f);

	return 0;
}

//3� passo - classifying the test set (testing.dat)
int classifyDatabase(int argc, char **argv){
	
	int n,i;
	float time;
	char fileName[256];
	FILE *f = NULL;
	struct timeval tic, toc;
	Subgraph *gTrain;	
	Subgraph *gTest;


	fflush(stdout);
	fprintf(stdout, "\nProgram that executes the test phase of the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 3.0 (2013)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if((argc != 3) && (argc != 2)){
	  fprintf(stderr, "\nusage opf_classify <P1> <P2>");
	  fprintf(stderr, "\nP1: test set in the OPF file format");
	  fprintf(stderr, "\nP2: precomputed distance file (leave it in blank if you are not using this resource\n");
	  exit(-1);
	}

    setDistanceOPFPedrosa(1);
	
	if(argc == 3) opf_PrecomputedDistance = 1;
	fprintf(stdout, "\nReading data files ..."); fflush(stdout);
	gTest = ReadSubgraph(argv[1]),
	gTrain = opf_ReadModelFile("/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/classifier.opf");
	fprintf(stdout, " OK"); fflush(stdout);

	if(opf_PrecomputedDistance)
		opf_DistanceValue = opf_ReadDistances(argv[2], &n);

	fprintf(stdout, "\nClassifying test set ..."); fflush(stdout);
	gettimeofday(&tic,NULL);
	opf_OPFClassifying(gTrain, gTest); gettimeofday(&toc,NULL);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"w");
	for (i = 0; i < gTest->nnodes; i++)
		fprintf(f,"%d\n",gTest->node[i].label);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ...");
	DestroySubgraph(&gTrain);
	DestroySubgraph(&gTest);
	if(opf_PrecomputedDistance){
		for (i = 0; i < n; i++)
			free(opf_DistanceValue[i]);
		free(opf_DistanceValue);
	}
	fprintf(stdout, " OK\n");

	time = ((toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001)/1000.0;
	fprintf(stdout, "\nTesting time: %f seconds\n", time); fflush(stdout);

	sprintf(fileName,"%s.time",argv[1]);
	f = fopen(fileName,"a");
	fprintf(f,"%f\n",time);
	//fprintf(fileNameResults,"%s %f \n","#Time Test		:",time);
	medidas[dist-1][0] = time;//time test
	fclose(f);

	return 0;
}
//4� passo - computing the accuracy over the test set (testing.dat)
int accuracyDatabase(int argc, char **argv)
{

	int i;
	float Acc;
	FILE *f = NULL;
	Subgraph *g = NULL;
	char fileName[256];


	fflush(stdout);
	fprintf(stdout, "\nProgram that computes OPF accuracy of a given set\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if(argc != 2){
		fprintf(stderr, "\nusage opf_accuracy <P1>");
		fprintf(stderr, "\nP1: data set in the OPF file format");
		exit(-1);
	}

	fprintf(stdout, "\nReading data file ..."); fflush(stdout);
	g = ReadSubgraph(argv[1]);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nReading output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"r");
	if(!f){
		fprintf(stderr,"\nunable to open file %s", argv[2]);
		exit(-1);
	}
	for (i = 0; i < g->nnodes; i++)
	  if (fscanf(f,"%d",&g->node[i].label) != 1) {
	    fprintf(stderr,"\nError reading node label");
	    exit(-1);
	  }
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nComputing accuracy ..."); fflush(stdout);
	Acc = opf_Accuracy(g);
	fprintf(stdout, "\nAccuracy: %.2f%%", Acc*100); fflush(stdout);

	fprintf(stdout, "\nWriting accuracy in output file ..."); fflush(stdout);
	sprintf(fileName,"%s.acc",argv[1]);
	f = fopen(fileName,"a");
	fprintf(f,"%f\n",Acc*100);
	//fprintf(fileNameResults,"d%s Acc = %f\n",_itoa(dist, distance, 10),Acc*100);
	

	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ..."); fflush(stdout);
	DestroySubgraph(&g);
	fprintf(stdout, " OK\n");

	return 0;
}
// executing the OPF learning procedure (training.dat evaluating.dat)
int opfLearnopf_learn(int argc, char **argv){
	float Acc, time;
	char fileName[512];
	int i,n;
	timer tic, toc;
	FILE *f = NULL;
	Subgraph *gTrain = NULL;
	Subgraph *gEval  = NULL;

	fflush(stdout);
	fprintf(stdout, "\nProgram that executes the learning phase for the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if((argc != 3) && (argc != 4)){
		fprintf(stderr, "\nusage opf_learn <P1> <P2> <P3>");
		fprintf(stderr, "\nP1: training set in the OPF file format");
		fprintf(stderr, "\nP2: evaluation set in the OPF file format");
		fprintf(stderr, "\nP3: precomputed distance file (leave it in blank if you are not using this resource\n");
		exit(-1);
	}

	
	if(argc == 4) opf_PrecomputedDistance = 1;
	fprintf(stdout, "\nReading data file ..."); fflush(stdout);
	gTrain = ReadSubgraph(argv[1]);
	gEval = ReadSubgraph(argv[2]);
	fprintf(stdout, " OK"); fflush(stdout);

	if(opf_PrecomputedDistance)
		opf_DistanceValue = opf_ReadDistances(argv[3], &n);

	fprintf(stdout, "\nLearning from errors in the evaluation set..."); fflush(stdout);
	gettimeofday(&tic,NULL); opf_OPFLearning(&gTrain, &gEval); gettimeofday(&toc,NULL);
	time = ((toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001)/1000.0;
	Acc = opf_Accuracy(gTrain);
	fprintf(stdout, "\nFinal opf_Accuracy in the training set: %.2f%%", Acc*100); fflush(stdout);
	Acc = opf_Accuracy(gEval);
	fprintf(stdout, "\nFinal opf_Accuracy in the evaluation set: %.2f%%", Acc*100); fflush(stdout);

	fprintf(stdout, "\n\nWriting classifier's model file ..."); fflush(stdout);
	opf_WriteModelFile(gTrain, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/classifier.opf"); fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ...");
	DestroySubgraph(&gTrain);
	DestroySubgraph(&gEval);
	if(opf_PrecomputedDistance){
		for (i = 0; i < n; i++)
			free(opf_DistanceValue[i]);
		free(opf_DistanceValue);
	}
	fprintf(stdout, " OK\n"); fflush(stdout);

	sprintf(fileName,"%s.time",argv[1]);
	f = fopen(fileName,"a");
	fprintf(f,"%f\n",time);
	fclose(f);

	return 0;
}
//distance normalization (parameter 0 at the final of the command line)
int opf_distance(int argc, char **argv){

	int i, j, distance = atoi(argv[2]), normalize = atoi(argv[3]);
	float **Distances = NULL, max = FLT_MIN;
	FILE *fp = NULL;
	Subgraph *sg = NULL;

	fflush(stdout);
	fprintf(stdout, "\nProgram that generates the precomputed distance file for the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if(argc != 4){
		fprintf(stderr, "\nusage opf_distance <P1> <P2> <P3>");
		fprintf(stderr, "\nP1: Dataset in the OPF file format");
		fprintf(stderr, "\nP2: Distance ID\n");
		fprintf(stderr, "\n	1 - Euclidean");
		fprintf(stderr, "\n	2 - Chi-Square");
		fprintf(stderr, "\n	3 - Manhattan (L1)");
		fprintf(stderr, "\n	4 - Canberra");
		fprintf(stderr, "\n	5 - Squared Chord");
		fprintf(stderr,"\n	6 - Squared Chi-Squared");
		fprintf(stderr,"\n	7 - BrayCurtis");
		fprintf(stderr, "\nP3: Distance normalization? 1- yes 0 - no");
		exit(-1);
	}

	sg = ReadSubgraph(argv[1]);
	fp = fopen("distances.dat", "wb");

	fwrite(&sg->nnodes, sizeof(int), 1, fp);

	Distances  = (float **)malloc(sg->nnodes*sizeof(float *));
	for (i = 0; i < sg->nnodes; i++)
		Distances[i] = (float *)malloc(sg->nnodes*sizeof(int));

	switch(distance){
		case 1:
			fprintf(stdout, "\n	Computing euclidean distance ...");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_EuclDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		case 2:
			fprintf(stdout, "\n	Computing chi-square distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_ChiSquaredDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		case 3:
			fprintf(stdout, "\n	Computing Manhattan distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_ManhattanDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		case 4:
			fprintf(stdout, "\n	Computing Canberra distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_CanberraDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
			case 5:
			fprintf(stdout, "\n	Computing Squared Chord distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_SquaredChordDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		case 6:
			fprintf(stdout, "\n	Computing Squared Chi-squared distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_SquaredChiSquaredDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		case 7:
			fprintf(stdout, "\n	Computing Bray Curtis distance ...\n");
			for (i = 0; i < sg->nnodes; i++){
				for (j = 0; j < sg->nnodes; j++){
					if(i == j) Distances[i][j] = 0.0;
					else Distances[sg->node[i].position][sg->node[j].position] = opf_BrayCurtisDist(sg->node[i].feat, sg->node[j].feat, sg->nfeats);
					if(Distances[sg->node[i].position][sg->node[j].position] > max) max = Distances[sg->node[i].position][sg->node[j].position];
				}
			}
		break;
		default:
			fprintf(stderr, "\nInvalid distance ID ...\n");
	}

	if (!normalize) max = 1.0;
	for (i = 0; i < sg->nnodes; i++){
		for (j = 0; j < sg->nnodes; j++){
			Distances[i][j]/=max;
			fwrite(&Distances[i][j], sizeof(float), 1, fp);
		}
	}

	fprintf(stdout, "\n\nDistances generated ...\n"); fflush(stdout);
	fprintf(stdout, "\n\nDeallocating memory ...\n");
	for (i = 0; i < sg->nnodes; i++)
		free(Distances[i]);
	free(Distances);

	DestroySubgraph(&sg);
	fclose(fp);


	return 0;
}
//	
int opf_cluster(int argc, char **argv){
  int i,n,op;
  float value;
  char fileName[256];
  FILE *f = NULL;
  Subgraph *g = NULL;
  float Hmax;
   double Vmax;

	fprintf(stdout, "\nProgram that computes clusters by OPF\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n");

	if((argc != 6) && (argc != 5)){
		fprintf(stderr, "\nusage opf_cluster <P1> <P2> <P3> <P4> <P5> <P6>");
		fprintf(stderr, "\nP1: unlabeled data set in the OPF file format");
		fprintf(stderr, "\nP2: kmax(maximum degree for the knn graph)");
		fprintf(stderr, "\nP3: P3 0 (height), 1(area) and 2(volume)");
		fprintf(stderr, "\nP4: value of parameter P3 in (0-1)");
		fprintf(stderr, "\nP5: precomputed distance file (leave it in blank if you are not using this resource");
		exit(-1);
	}

	if(argc == 6) opf_PrecomputedDistance = 1;
	fprintf(stdout, "\nReading data file ...");
	g = ReadSubgraph(argv[1]);

	if(opf_PrecomputedDistance){
	  opf_DistanceValue = opf_ReadDistances(argv[5], &n);
	}

	op = atoi(argv[3]);

	opf_BestkMinCut(g,1,atoi(argv[2])); //default kmin = 1

	value = atof(argv[4]);
	if ((value < 1)&&(value>0)){
	  fprintf(stdout, "\n\n Filtering clusters ... ");
	  switch(op){
	  case 0:
	    fprintf(stdout, "\n by dome height ... ");
	    Hmax=0;
	    for (i=0; i < g->nnodes; i++)
	      if (g->node[i].dens > Hmax)
		Hmax = g->node[i].dens;
	    opf_ElimMaxBelowH(g, value*Hmax);
	    break;
	  case 1:
	    fprintf(stdout, "\n by area ... ");
	    opf_ElimMaxBelowArea(g, (int)(value*g->nnodes));
	    break;
	  case 2:
	    fprintf(stdout, "\n by volume ... ");
	    Vmax=0;
	    for (i=0; i < g->nnodes; i++)
	      Vmax += g->node[i].dens;
	    opf_ElimMaxBelowVolume(g, (int)(value*Vmax/g->nnodes));
	    break;
	  default:
	    fprintf(stderr, "\nInvalid option for parameter P3 ... ");
	    exit(-1);
	    break;
	  }
	}

	fprintf(stdout, "\n\nClustering by OPF ");
	opf_OPFClustering(g);
	printf("num of clusters %d\n",g->nlabels);
	

	/* If the training set has true labels, then create a
	   classifier by propagating the true label of each root to
	   the nodes of its tree (cluster). This classifier can be
	   evaluated by running opf_knn_classify on the training set
	   or on unseen testing set. Otherwise, copy the cluster
	   labels to the true label of the training set and write a
	   classifier, which essentially can propagate the cluster
	   labels to new nodes in a testing set. */

	if (g->node[0].truelabel!=0){ // labeled training set
	  g->nlabels = 0;
	  for (i = 0; i < g->nnodes; i++){//propagating root labels
	    if (g->node[i].root==i)
	      g->node[i].label = g->node[i].truelabel;
	    else
	      g->node[i].label = g->node[g->node[i].root].truelabel;
	  }

	  for (i = 0; i < g->nnodes; i++){
		  // retrieve the original number of true labels
		  if (g->node[i].label > g->nlabels)
			  g->nlabels = g->node[i].label;
	  }
	}else{ // unlabeled training set
	  for (i = 0; i < g->nnodes; i++)
	    g->node[i].truelabel = g->node[i].label+1;
	}

	fprintf(stdout, "\nWriting classifier's model file ..."); fflush(stdout);
	opf_WriteModelFile(g, "/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/classifier.opf");
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"w");
	for (i = 0; i < g->nnodes; i++)
		fprintf(f,"%d\n",g->node[i].label);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\n\nDeallocating memory ...\n");
	DestroySubgraph(&g);
	if(opf_PrecomputedDistance){
	  for (i = 0; i < n; i++)
	    free(opf_DistanceValue[i]);
	  free(opf_DistanceValue);
	}

	return 0;
}
//
int opf_knn_classify(int argc, char **argv){

	int n,i;
	float time;
	char fileName[256];
	FILE *f = NULL;
	timer tic, toc;
	Subgraph *gTest = NULL;
	Subgraph *gTrain = NULL;


	fflush(stdout);
	fprintf(stdout, "\nProgram that executes the test phase of the OPF classifier\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	if((argc != 3) && (argc != 2)){
		fprintf(stderr, "\nusage opf_knn_classify <P1> <P2>");
		fprintf(stderr, "\nP1: test set in the OPF file format");
		fprintf(stderr, "\nP2: precomputed distance file (leave it in blank if you are not using this resource\n");
		exit(-1);
	}
	
	
	if(argc == 3) opf_PrecomputedDistance = 1;
	fprintf(stdout, "\nReading data files ..."); fflush(stdout);
	gTest = ReadSubgraph(argv[1]);
	gTrain = opf_ReadModelFile("/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/classifier.opf");
	fprintf(stdout, " OK"); fflush(stdout);

	if(opf_PrecomputedDistance)
		opf_DistanceValue = opf_ReadDistances(argv[2], &n);

	fprintf(stdout, "\nClassifying test set ..."); fflush(stdout);
	gettimeofday(&tic,NULL);
	opf_OPFKNNClassify(gTrain, gTest); gettimeofday(&toc,NULL);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nWriting output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"w");
	for (i = 0; i < gTest->nnodes; i++)
		fprintf(f,"%d\n",gTest->node[i].label);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nDeallocating memory ...");
	DestroySubgraph(&gTrain);
	DestroySubgraph(&gTest);
	if(opf_PrecomputedDistance){
		for (i = 0; i < n; i++)
			free(opf_DistanceValue[i]);
		free(opf_DistanceValue);
	}
	fprintf(stdout, " OK\n");

	time = ((toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001)/1000.0;
	fprintf(stdout, "\nTesting time: %f seconds\n", time); fflush(stdout);

	sprintf(fileName,"%s.time",argv[1]);
	f = fopen(fileName,"a");
	fprintf(f,"%f\n",time);
	fclose(f);

	return 0;
}

int opf2txt(int argc, char **argv){

	FILE *fpIn = NULL,*fpOut = NULL;
	int n, ndata, nclasses, label, i,j, id;
	float aux;

	/*
	100(numero de amostras) 3(qtd de classes) 2 (tam do vetor de atributos) 
	0 (sample 0) 1 (classe 1) -1.528822 0.904446 (atributos) 
	1 1 -2.036158 -0.042683 

	*/
	if (argc != 3) {
		fprintf(stderr,"\nusage: opf2txt <opf file name> <output file name> \n");
		exit(-1);
	}

    fprintf(stderr, "\nProgram to convert files written in the OPF binary format to the OPF ASCII format.");
    
	
	fpIn = fopen(argv[1],"rb");
	fpOut = fopen(argv[2],"w");

	/*gravando numero de objetos*/
	fread(&n,sizeof(int),1,fpIn);
    fprintf(fpOut,"%d ",n);

	/*gravando numero de classes*/
	fread(&nclasses,sizeof(int),1,fpIn);
    fprintf(fpOut,"%d ",nclasses);

	/*gravando tamanho vetor de caracteristicas*/
	fread(&ndata,sizeof(int),1,fpIn);
	fprintf(fpOut,"%d ",ndata);

	fprintf(fpOut,"\n");
	/*gravando vetor de caracteristicas*/
	for(i = 0; i < n; i++){
		fread(&id,sizeof(int),1,fpIn);
		fread(&label,sizeof(int),1,fpIn);
		fprintf(fpOut,"%d %d ",id,label);
		for(j = 0; j < ndata; j++)
		{
			fread(&aux,sizeof(float),1,fpIn);
			fprintf(fpOut,"%f ",aux);
		}
		fprintf(fpOut,"\n");
	}
	fclose(fpIn);
	fclose(fpOut);

	return 0;
}

int txt2opf(int argc, char **argv)
{
	FILE *fpIn = NULL,*fpOut = NULL;
	int n, ndata, nclasses, i,j, id,label;
	float aux;

	if (argc != 3) 
	{
		fprintf(stderr,"\nusage txt2opf <P1> <P2>\n");
		fprintf(stderr,"\nP1: input file name in the OPF ASCII format");
		fprintf(stderr,"\nP2: output file name in the OPF binary format\n");
		exit(-1);
	}

	fprintf(stderr, "\nProgram to convert files written in the OPF ASCII format to the OPF binary format.");

	

	fpIn = fopen(argv[1],"r");
	fpOut = fopen(argv[2],"wb");

	/*writting the number of samples*/
	if (fscanf(fpIn,"%d",&n) != 1) {
	  fprintf(stderr,"Could not read number of samples");
	  exit(-1);
	}
	printf("\n number of samples: %d",n);
	fwrite(&n,sizeof(int),1,fpOut);

	/*writting the number of classes*/
	if (fscanf(fpIn,"%d",&nclasses) != 1) {
	  fprintf(stderr,"Could not read number of classes");
	  exit(-1);
	}

 	printf("\n number of classes: %d",nclasses); 
	fwrite(&nclasses,sizeof(int),1,fpOut);

	/*writting the number of features*/
	if (fscanf(fpIn,"%d",&ndata) != 1) {
	  fprintf(stderr,"Could not read number of features");
	  exit(-1);
	}

	printf("\n number of features: %d",ndata);
	fwrite(&ndata,sizeof(int),1,fpOut);
	
	/*writting data*/

	for(i = 0; i < n; i++)	{
	  if (fscanf(fpIn,"%d",&id) != 1) {
	    fprintf(stderr,"Could not read sample id");
	    exit(-1);
	  }
	  fwrite(&id,sizeof(int),1,fpOut);
	  
	  if (fscanf(fpIn,"%d",&label) != 1) {
	    fprintf(stderr,"Could not read sample label");
	    exit(-1);
	  }
	  fwrite(&label,sizeof(int),1,fpOut);
	  
	  for(j = 0; j < ndata; j++){
	    if (fscanf(fpIn,"%f",&aux) != 1) {
	      fprintf(stderr,"Could not read sample features");
	      exit(-1);
	    }

	    fwrite(&aux,sizeof(float),1,fpOut);
	  }
	}
	
	fclose(fpIn);
	fclose(fpOut);

	return 0;
}

int statistics(int argc, char **argv){
	
	FILE *fpIn = NULL;
	int i, it = atoi(argv[2]);
	float Std = 0.0f, MeanAcc = 0.0f, aux, *acc = NULL;

	if(argc != 4){
		fprintf(stderr,"\nusage statistics <file name> <running times> <message>\n");
		exit(-1);
	}
	/*Computing mean accuracy and standard deviation***/
	fpIn = fopen(argv[1],"r");
	if(!fpIn){
		fprintf(stderr,"\nunable to open file %s\n",argv[1]);
		exit(-1);
	}
	
	acc = (float *)malloc(it*sizeof(float));
	for (i = 1;i <= it ; i++){
	  if (fscanf(fpIn,"%f",&aux) != 1) {
	    fprintf(stderr,"\n Could not read accuracy");
	    exit(-1);
	  }
	  acc[i-1] = aux;
	  MeanAcc+=aux;
	}
	MeanAcc/=it;
	for (i = 0; i < it; i++)
		Std+=pow(acc[i]-MeanAcc,2);
	Std=sqrt(Std/it);

	fclose(fpIn);
	free(acc);

	fprintf(stderr,"\n%s %f with standard deviation: %f\n",argv[3],MeanAcc,Std);

	return 0;
}
int opfmedidamodificadas(int argc, char **argv)
{

	int i,k;
	float Acc;
	size_t result;
	FILE *f = NULL;
	char fileName[256];
	// eduardo
	float countErr = 0.0f;
	float auxf;
	float auxi;
	float acc = 0.0f, error = 0.0f;
	int *nclass = NULL, nlabels=0;
	int ** confMatrix;
	//float **confMatrixPercentual;
	int j=0;
	float * specificity, *sensitivity, *ppredict, *fposrate, *ppv,*accpc,*fscore;//accpc = acuracia por classe
	float specificityMean,sensitivityMean,accpcMean,fscoreMean,ppvMean;
	float SeDiv=0, SpDiv=0;
	int TP, TN, FP, FN; //por classe
	int MVP, MFN, MP, MFP, MVN, MN, MPLINHA,MNLINHA, MP_MAIS_N; // para o modelo
	Subgraph *g = NULL;

	fflush(stdout);
	fprintf(stdout, "\nProgram that computes OPF accuracy of a given set\n");
	fprintf(stdout, "\nIf you have any problem, please contact: ");
	fprintf(stdout, "\n- alexandre.falcao@gmail.com");
	fprintf(stdout, "\n- papa.joaopaulo@gmail.com\n");
	fprintf(stdout, "\nLibOPF version 2.0 (2009)\n");
	fprintf(stdout, "\nModificado por Eduardo Luz (2011)\n");
	fprintf(stdout, "\n"); fflush(stdout);

	fileNameResults = fopen("/Users/carlosbarros/Downloads/projetos_xcode/appOPF/AppOPF/AppOPF/resultados.txt", "w");

	if(argc != 2){
		fprintf(stderr, "\nusage opf_accuracy <P1>");
		fprintf(stderr, "\nP1: data set in the OPF file format");
		exit(-1);
	}

   
     setDistanceOPFPedrosa(1);
	// ----

	fprintf(stdout, "\nReading data file ..."); fflush(stdout);
	g = ReadSubgraph(argv[1]);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nReading output file ..."); fflush(stdout);
	sprintf(fileName,"%s.out",argv[1]);
	f = fopen(fileName,"r");
	if(!f){
		fprintf(stderr,"\nunable to open file %s", argv[2]);
		exit(-1);
	}
	
	for (i = 0; i < g->nnodes; i++)
		result = fscanf(f,"%d",&g->node[i].label);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nComputing accuracy ..."); fflush(stdout);
	Acc = opf_Accuracy(g);
	fprintf(stdout, "\nAccuracy: %.2f%%", Acc*100); fflush(stdout);
	medidas[dist-1][2] = Acc*100;//Acuracia opf
	fprintf(fileNameResults,"%s %f \n","#Acc OPF		:",Acc*100);
	fprintf(stdout, "\nWriting accuracy in output file ..."); fflush(stdout);
	sprintf(fileName,"%s.acc",argv[1]);
	f = fopen(fileName,"a");
	result = fprintf(f,"%f\n",Acc*100);
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);
	
	// modifica��o feita por Eduardo 02/10/2011
	//O campo truelabel eh carregado quando voc� le o arquivo, ou seja, ele corresponde ao r�tulo original. 
	//O campo label armazena o r�tulo dado pelo classificador.
	
	fprintf(stdout, "\nModifica��o para reportar acur�cia global, Se e Sp"); fflush(stdout);
	fprintf(stdout, "\nFeito dor Eduardo Luz - 02/10/2011"); fflush(stdout);
	fprintf(stdout, "\nComputing global accuracy, Se and Sp ..."); fflush(stdout);
	
	for (i = 0; i < g->nnodes; i++){
		if(g->node[i].truelabel != g->node[i].label){
			countErr++;
		}
	}
	
	acc = (g->nnodes - countErr) / g->nnodes;
	medidas[dist-1][3] = acc*100;//Acuracia Global
	fprintf(fileNameResults,"%s %f \n","#Acc Global		:",acc*100);
	fprintf(stdout, "\nAcuracia Global: %.2f%%", acc*100); fflush(stdout);
	
	//calcula especificidade e sensitividade
	nclass = AllocIntArray(g->nlabels+1);
	
	fprintf(stdout, "\n Passo0: loca nclass"); fflush(stdout);

	for (i = 0; i < g->nnodes; i++){
		nclass[g->node[i].truelabel]++;	// quantidade de inst�ncias reais de cada classe
	}
	
	fprintf(stdout, "\n Passo1"); fflush(stdout);
	
	// calcula matriz de confusao
	confMatrixPercentual = (float **)calloc(g->nlabels, sizeof(float *));
	for(i=0; i< g->nlabels; i++)
		confMatrixPercentual[i] = (float *)calloc(g->nlabels, sizeof(int));

	confMatrix = (int **)calloc(g->nlabels, sizeof(int *));
	for(i=0; i< g->nlabels; i++)
		confMatrix[i] = (int *)calloc(g->nlabels, sizeof(int));

	fprintf(stdout, "\n Passo2: aloca MC"); fflush(stdout);

	for(i=0; i< g->nlabels; i++)
		for(j=0; j< g->nlabels; j++)
			confMatrixPercentual[i][j]=0;

	for(i=0; i< g->nlabels; i++)
		for(j=0; j< g->nlabels; j++)
			confMatrix[i][j]=0;
	
	fprintf(stdout, "\n Passo2.5: init MC"); fflush(stdout);
			
	for (i = 0; i < g->nnodes; i++){
		//fprintf(stdout, "\n Passo2.5: trueL=%d, label=%d", g->node[i].truelabel, g->node[i].label); fflush(stdout);
		confMatrix[g->node[i].truelabel-1][g->node[i].label-1]++;
		
	}
	// calcula especificidade e sensibilidade (para cada classe)
	specificity = (float *)calloc(g->nlabels, sizeof(float));
	sensitivity = (float *)calloc(g->nlabels, sizeof(float));
	ppv         = (float *)calloc(g->nlabels, sizeof(float));
	accpc       = (float *)calloc(g->nlabels, sizeof(float));
	fscore      = (float *)calloc(g->nlabels, sizeof(float));
	k=0;
	
	for (i=0; i<g->nlabels; i++){ 
		for (j=0; j< g->nlabels; j++){
			k=k+confMatrix[i][j];
		}
	} 
	//computa total da matriz	
	fprintf(fileNameResults,"\nspecificity		sensitivity		ppv		accpc	fscore \n");
	for(i=0; i< g->nlabels; i++){
		TP=confMatrix[i][i];//Calcula TP
		FP=0;
		FN=0;
		TN=0;
		for(j=0; j< g->nlabels; j++){ //Calcula FN e FP
			FP=FP+confMatrix[j][i];
			FN=FN+confMatrix[i][j];
		}
		FN=FN-TP;
		FP=FP-TP;
		TN=k-FP-FN-TP;
		
		specificity[i] = (float)TN/(TN+FP); //ppv[i] = (float)TP/(TP+FP);//Precis�o da Classe C Taxa de Verdadeiros Negativos.
		fprintf(fileNameResults,"c%d %f",i,specificity[i]);
		sensitivity[i] = (float)TP/(TP+FN);//(Taxa de Verdadeiros Positivos) Recall
		fprintf(fileNameResults," %f",sensitivity[i]);
		ppv[i]         = (float)TP/(TP+FP);   //precision
		fprintf(fileNameResults," %f",ppv[i]);
		accpc[i]       = (float)(TP+TN)/(TP+TN+FP+FN);//
		fprintf(fileNameResults," %f",accpc[i]);
		fscore[i]      = (float)(2*(ppv[i]*sensitivity[i]))/(ppv[i]+sensitivity[i]);
		fprintf(fileNameResults," %f",fscore[i]);
		fprintf(fileNameResults,"\n");
	}		
	
		

	/*
	specificityMean=0;
	sensitivityMean=0;
	accpcMean=0;
	fscoreMean=0;
	ppvMean=0;

	for(i=0; i< g->nlabels; i++){
		specificityMean+=specificity[i];
		sensitivityMean+=sensitivity[i];
		accpcMean+=accpc[i];
		fscoreMean+=fscore[i];
		ppvMean+=ppv[i];
		
	}

	specificityMean/=g->nlabels;
	sensitivityMean/=g->nlabels;
	accpcMean/=g->nlabels;
	fscoreMean/=g->nlabels;
	ppvMean/=g->nlabels;

	medidas[dist-1][4] = specificityMean;
	medidas[dist-1][5] = sensitivityMean;
	medidas[dist-1][6] = accpcMean;
	medidas[dist-1][7] = fscoreMean;
	medidas[dist-1][8] = ppvMean;
	nlabelss =  g->nlabels;
	*/

	fprintf(stdout, "\nEscreve especificidade no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.sp",argv[1]);
	f = fopen(fileName,"a");
	for(i=0; i< g->nlabels; i++){
		result = fprintf(f,"%f\n",specificity[i]*100);
	}
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);
	
	fprintf(stdout, "\nEscreve sensibilidade no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.se",argv[1]);
	f = fopen(fileName,"a");
	for(i=0; i< g->nlabels; i++){
		result = fprintf(f,"%f\n",sensitivity[i]*100);
	}	
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nEscreve ppv no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.ppv",argv[1]);
	f = fopen(fileName,"a");
	for(i=0; i< g->nlabels; i++){
		result = fprintf(f,"%f\n",ppv[i]*100);
	}

	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nEscreve accpc no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.accpc",argv[1]);
	f = fopen(fileName,"a");
	for(i=0; i< g->nlabels; i++){
		result = fprintf(f,"%f\n",accpc[i]*100);
	}
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	fprintf(stdout, "\nEscreve fscore no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.fscore",argv[1]);
	f = fopen(fileName,"a");
	for(i=0; i< g->nlabels; i++){
		result = fprintf(f,"%f\n",fscore[i]*100);
	}
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	for (i = 0; i < g->nnodes; i++){
		confMatrixPercentual[g->node[i].truelabel-1][g->node[i].label-1]++;		
	}
	for(i=0; i< g->nlabels; i++){
		for(j=0; j< g->nlabels; j++){
			confMatrixPercentual[i][j] = 100*confMatrixPercentual[i][j]/nclass[i+1];
		}		
	}

	//fazendo a transposta
	for (i = 0; i < g->nlabels; i++) {
    for (j = i+1; j < g->nlabels; j++) {
      if (j != i) {
	auxf = confMatrixPercentual[i][j];
	confMatrixPercentual[i][j] = confMatrixPercentual[j][i];
	confMatrixPercentual[j][i] = auxf;
      }
    }
  }

	fprintf(fileNameResults,"\n%s\n","#Matrix Confusion Percentual:");
	for(i=0; i< g->nlabels; i++){
		for(j=0; j< g->nlabels; j++){
			fprintf(fileNameResults,"%.2f ",confMatrixPercentual[i][j]);
		}
		fprintf(fileNameResults,"\n");
	}
	fprintf(fileNameResults,"\n");

	//fazendo a transposta
	for (i = 0; i < g->nlabels; i++) {
    for (j = i+1; j < g->nlabels; j++) {
      if (j != i) {
	auxi = confMatrix[i][j];
	confMatrix[i][j] = confMatrix[j][i];
	confMatrix[j][i] = auxi;
			}
		}
	}
	fprintf(fileNameResults,"%s \n","#Matrix Confusion :");
	for(i=0; i< g->nlabels; i++){
		for(j=0; j< g->nlabels; j++){
			fprintf(fileNameResults,"%6d",confMatrix[i][j]);
		}
		fprintf(fileNameResults,"\n");
	}
	fprintf(fileNameResults,"\n");


	fprintf(stdout, "\n Passo3: cria MC"); fflush(stdout);

	fprintf(stdout, "\nEscreve matriz de confu sao no arquivo de sa�da ..."); fflush(stdout);
	sprintf(fileName,"%s.conf.mat",argv[1]);
	f = fopen(fileName,"a");
	
	for(i=0; i< g->nlabels; i++){
		for(j=0; j< g->nlabels; j++){
			result = fprintf(f,"%6d ",confMatrix[i][j]);//confMatrixPercentual //%.2f
		}
		fprintf(f,"\n");
	}
	fprintf(f,"\n\n");
	
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);

	/////////////---matriz em termos de percentuais
	fprintf(stdout, "\nEscreve matriz de confusao percentual ..."); fflush(stdout);
	sprintf(fileName,"%s.confpercentual.mat",argv[1]);
	f = fopen(fileName,"a");
	
	for(i=0; i< g->nlabels; i++){
		for(j=0; j< g->nlabels; j++){
			result = fprintf(f,"%.2f ",confMatrixPercentual[i][j]);//%6d 
		}
		fprintf(f,"\n");
	}
	fprintf(f,"\n\n");
	
	fclose(f);
	fprintf(stdout, " OK"); fflush(stdout);	
	
	// desaloca matrizes e vetores
	for(i=0; i < g->nlabels; i++)
		free(confMatrix[i]);

	free(confMatrix);
	confMatrix = NULL;

	for(i=0; i < g->nlabels; i++)
		free(confMatrixPercentual[i]);

	free(confMatrixPercentual);
	confMatrixPercentual = NULL;

	free(nclass);
	nclass = NULL;

	free(specificity);
	specificity = NULL;
	free(sensitivity);
	sensitivity = NULL;
	
	fprintf(stdout, "\nDeallocating memory ..."); fflush(stdout);
	DestroySubgraph(&g);
	fprintf(stdout, " OK\n");
	
	return 0;
}
int somadoisnumero(int a,int b)
{
	return a+b;
}
